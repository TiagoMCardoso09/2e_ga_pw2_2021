const express = require("express");
const servidor = express();
const mysql = require("mysql2");
const banco = mysql.createPool({
  database: "2e_ga_210922",
  user: "root",
  password: "",
  host: "localhost",
  port: 3306
});

const bodyParser = require("body-parser");

servidor.use(bodyParser.urlencoded({ extended: false }));
servidor.use(bodyParser.json());

// 1º parte - Cadastro de veículos
servidor.post("/cadastro", (req, res, next) => {
  let body = req.body;

  banco.getConnection((error, conn) => {
    if (error) {
      return res
        .status(500)
        .send({ Mensagem: "Erro no servidor", Detalhes: error });
    }
    conn.query(QUERY, (error, resultado) => {
      conn.release();
      if (error) {
        return res
          .status(500)
          .send({ Mensagem: "Não foi possível atender à solicitação", Detalhes: error });
      }
      return res
        .status(200)
        .send({ Verbo: "post",
        Mensagem: "Cadastro realizado com sucesso!"
      })
    })
  })
  const QUERY = `INSERT INTO veiculos (modelo, marca, preco_venda, proprietario) VALUES('${body.modelo}', '${body.marca}', ${body.preco_venda}, '${body.proprietario}')`;
});


// 2º parte - Exibição de veículos ordenados por marca
servidor.get("/veiculos",(req, res, next) =>{
  const QUERY = `SELECT * FROM veiculos ORDER BY marca`;

  banco.getConnection((error, conn) =>{
    if(error){
      return res.status(500).send({
        Erro: "Erro no servidor, verifique",
        Detalhes: error
        })
    }

    conn.query(QUERY,(error,resultado) => {
      conn.release()

      if (error) {
        return res.status(500).send({
          Mensagem: "Não foi possível atender à solicitação",
          Detalhes: error
        })
      }

      return res.status(200).send({
        Mensagem: "Dados retornados com sucesso",
        Dados: resultado
      })
    })
  })
})

// 3º parte - Exibição de veículos por determinadas marcas passadas por parâmetros de URL
servidor.get("/porMarcas/:marcas",(req, res, next) =>{
  let marcas = req.params.marcas;

  const QUERY = `SELECT * FROM veiculos WHERE marca LIKE '%${marcas}%'`;

  banco.getConnection((error, conn) =>{
    if(error){
      return res.status(500).send({
        Erro: "Erro no servidor, verifique",
        Detalhes: error
        })
    }

    conn.query(QUERY,(erro,resultado) => {
      conn.release()

      if (error) {
        return res.status(500).send({
          Erro: "Não foi possível atender à solicitação",
          Detalhes: error
        })
      }

      return res.status(200).send({
        Mensagem: "Consulta realizada com sucesso",
        Dados: resultado
      })
    })
  })
})

// 4º parte - Exibição de veículos por determinados proprietários passados por parâmetros de URL
servidor.get("/porProprietarios/:proprietario",(req, res, next) =>{
  let proprietario = req.params.proprietario;

  const QUERY = `SELECT * FROM veiculos WHERE proprietario LIKE '%${proprietario}%'`;

  banco.getConnection((error, conn) =>{
    if(error){
      return res.status(500).send({
        Erro: "Erro no servidor, verifique",
        Detalhes: error
        })
    }

    conn.query(QUERY,(erro,resultado) => {
      conn.release()

      if (error) {
        return res.status(500).send({
          Erro: "Não foi possível atender à solicitação",
          Detalhes: error
        })
      }

      return res.status(200).send({
        Mensagem: "Consul realizada com sucesso",
        Dados: resultado
      })
    })
  })
})

// 5º parte - Exibição de veículos com valor maior do que passado pelo parâmetro de URL
servidor.get("/porValor/:valor",(req, res, next) =>{
  let valor = req.params.valor;

  const QUERY = `SELECT * FROM veiculos WHERE preco_venda >= ${valor}`;

  banco.getConnection((error, conn) =>{
    if(error){
      return res.status(500).send({
        Erro: "Erro no servidor, verifique",
        Detalhes: error
        })
    }

    conn.query(QUERY,(erro,resultado) => {
      conn.release()

      if (error) {
        return res.status(500).send({
          Erro: "Não foi possível atender à solicitação",
          Detalhes: error
        })
      }

      return res.status(200).send({
        Mensagem: "Consulta realizada com sucesso",
        Dados: resultado
      })
    })
  })
})

// 6º parte - Alteração dos dados de um veículo, utilizando como critério o ID passado pelo parâmetro de URL
servidor.patch("/modificar/:id",(req, res, next) =>{
  let id    = req.params.id;
  let body  = req.body;

  const QUERY = `UPDATE veiculos SET modelo = '${body.modelo}', marca = '${body.marca}', preco_venda = ${body.preco_venda}, proprietario = '${body.proprietario}' WHERE id LIKE ${id}`;

  banco.getConnection((error, conn) =>{
    if(error){
      return res.status(500).send({
        Erro: "Erro no servidor, verifique",
        Detalhes: error
        })
    }

    conn.query(QUERY,(erro,resultado) => {
      conn.release()

      if (error) {
        return res.status(500).send({
          Erro: "Não foi possível atender à solicitação",
          Detalhes: error
        })
      }

      return res.status(200).send({
        Mensagem: "Modificação realizada com sucesso",
        Dados: resultado
      })
    })
  })
})

// 7º parte - Exclusão de um veículo, utilizando como critério o ID passado pelo parâmetro de URL
servidor.delete("/deletarID/:id", (req,res,next) =>{
  let id = req.params.id;
  
  const QUERY = `DELETE FROM veiculos WHERE id = ${id}`;

  banco.getConnection((error,conn) =>{
    if (error) {
      return res.status(500).send({
        Mensagem: "Erro no servidor, verifique",
        Erro: error
      })
    }

    conn.query(QUERY, (erro, resultado) =>{
      conn.release()

      if (erro) {
        return res.status(500).send({
          Mensagem: "Não foi possível atender à solicitação",
          Erro: error
        })
      }

      if (resultado.affectedRows > 0) {
        return res.status(200).send({
          mensagem: `Cliente ${id}, excluído com sucesso`
        })
      }else{
        return res.status(200).send({
          mensagem: `Cliente ${id}, não existe no banco de dados`
        })
      }
    })
  })
})

// 8º parte - Exclusão de um veículo, por determinada marca passada pelo parâmetro de URL
servidor.delete("/deletarMarca/:marca", (req,res,next) =>{
  let marca = req.params.marca;
  
  const QUERY = `DELETE FROM veiculos WHERE marca = '${marca}'`;

  banco.getConnection((error,conn) =>{
    if (error) {
      return res.status(500).send({
        Mensagem: "Erro no servidor, verifique",
        Erro: error
      })
    }

    conn.query(QUERY, (erro, resultado) =>{
      conn.release()

      if (erro) {
        return res.status(500).send({
          Mensagem: "Não foi possível atender à solicitação",
          Erro: error
        })
      }

      if (resultado.affectedRows > 0) {
        return res.status(200).send({
          mensagem: `Carros da marca ${marca}, excluídos com sucesso`
        })
      }else{
        return res.status(200).send({
          mensagem: `Não existem carros da ${marca} no banco de dados`
        })
      }
    })
  })
})

// 9º parte - Exclusão de um veículo, de um determinado modelo e que tenha um preço de venda maior ou igual ao informado, utilizando os dados passados por parâmetro de URL
servidor.delete("/deletarModeloValor/:modelo/:valor", (req,res,next) =>{
  let modelo  = req.params.modelo;
  let valor   = req.params.valor;

  const QUERY = `DELETE FROM veiculos WHERE modelo = "${modelo}" && preco_venda >= ${valor}`;

  banco.getConnection((error,conn) =>{
    if (error) {
      return res.status(500).send({
        Mensagem: "Erro no servidor, verifique",
        Erro: error
      })
    }

    conn.query(QUERY, (erro, resultado) =>{
      conn.release()

      if (erro) {
        return res.status(500).send({
          Mensagem: "Não foi possível atender à solicitação",
          Erro: error
        })
      }

      if (resultado.affectedRows > 0) {
        return res.status(200).send({
          mensagem: `Carros da ${modelo} e valores maiores do que ${valor}, excluídos com sucesso`
        })
      }else{
        return res.status(200).send({
          mensagem: `Não existem carros da ${modelo} com valores maiores do que ${valor} no banco de dados`
        })
      }
    })
  })
})

// Configuração da porta do servidor
servidor.listen(3000, () => {
  console.log("Executando");
})